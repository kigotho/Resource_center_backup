# Changelog

![Pick Your Knows!](https://raw.githubusercontent.com/berzerk0/BEWGor/master/bewgor_nose.png)

### 26 May 2017
* Added Changelog
* Added information to README.md
* Added Sample File
* Added Better Logo
* Added Added Contribution Guidelines
* Hid Secret Message in repo - “…with a rubber hose.”
* Delayed releasing the code yet again because bugs.
* Made formatting fixes to README.md, as expected


### 27 May 2017
* Ran code through Codacy
* Updated all files before official release
* Changed the term ‘literals’ to ‘term’s because of potential confusion
* DROPPED ALPHA RELEASE


### 28 May 2017
* Made formatting/proofreading changes to the README.md
* Adding Issue About Number of Junk Lines - thinking of ways to slim down
* Updated Contributing.md
* Fixed the “Remove Leading Zeroes” Function - no longer named “createNoZeroDays”

### 07 August 2017
* Fixed a few typos

### 9 Feb 2018
* Haven't forgotten about you, BEWGor!
* Fixed some formatting and typos
